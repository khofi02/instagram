<?php
include "koneksi.php";
require "functions.php";

if (isset($_POST['simpan'])) {

    $foto = upload();
    $caption = $_POST['caption'];
    $harga = $_POST['harga'];

    $sql = "INSERT INTO post (foto,caption,harga) VALUES ('$foto', '$caption','$harga')";
$query = mysqli_query($koneksi, $sql);

if ($query) {
    header("location:index.php?tambah=sukses");
} else {
    header("location:index.php?tambah=gagal");
}

}


?>