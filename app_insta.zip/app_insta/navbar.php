<nav class="navbar navbar-expand-lg bg-light fixed-top" data-bs-theme="secondary">
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <center>
    <a class="navbar-brand" href="#">
      <img src="01.ico" width="40" height="30" alt="">
    </a>
</center>
 
</nav>
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Sweet Cake</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor03" aria-controls="navbarColor03" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarColor03">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">

            <span class="visually-hidden">(current)</span>
          </a>
      </ul>

    </div>
  </div>
</nav>